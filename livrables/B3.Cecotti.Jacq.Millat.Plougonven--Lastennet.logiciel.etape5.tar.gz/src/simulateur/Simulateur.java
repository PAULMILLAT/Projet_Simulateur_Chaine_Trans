package simulateur;

import destinations.Destination;
import destinations.DestinationFinale;
import information.Information;
import sources.Source;
import sources.SourceAleatoire;
import sources.SourceFixe;
import transmetteurs.CodeurCanal;
import transmetteurs.DecodeurCanal;
import transmetteurs.Emetteur;
import transmetteurs.InsertionEntete;
import transmetteurs.Recepteur;
import transmetteurs.RecepteurSonde;
import transmetteurs.Transmetteur;
import transmetteurs.TransmetteurAnalogiqueBruite;
import transmetteurs.TransmetteurAnalogiqueTrajetsMultiples;
import transmetteurs.TransmetteurParfait;
import visualisations.SondeAnalogique;
import visualisations.SondeLogique;
import visualisations.SondeOeil;


/** La classe Simulateur permet de construire et simuler une chaîne de
 * transmission composée d'une Source, d'un nombre variable de
 * Transmetteur(s) et d'une Destination.
 * @author cousin
 * @author prou
 * @author Paul
 * @author Yann
 * @author Damien
 * @author Enzo
 */
public class Simulateur {

    /** liste des options reconnues par la commande unique, utilisee pour detecter
     * la fin de la liste de couples (dt, ar) qui suit -ti */
    private static final java.util.Set<String> OPTIONS_CONNUES = new java.util.HashSet<String>(
        java.util.Arrays.asList("-s", "-seed", "-mess", "-form", "-nbEch", "-ampl", "-snrpb", "-snr", "-ti", "-oeil", "-sondage", "-codeur"));

    /** indique si le Simulateur utilise des sondes d'affichage */
    private boolean affichage = false;

    /** indique si le Simulateur utilise un message généré de manière aléatoire (message imposé sinon) */
    private boolean messageAleatoire = true;

    /** indique si le Simulateur utilise un germe pour initialiser les générateurs aléatoires */
    private boolean aleatoireAvecGerme = false;

    /** la valeur de la semence utilisée pour les générateurs aléatoires */
    private Integer seed = null; // pas de semence par défaut

    /** la longueur du message aléatoire à transmettre si un message n'est pas imposé */
    private int nbBitsMess = 100;

    /** la chaîne de caractères correspondant à m dans l'argument -mess m */
    private String messageString = "100";

    // --- Paramètres de transmission analogique (TP2) ---

    /** indique si la simulation doit utiliser une chaîne analogique */
    private boolean transmissionAnalogique = false;

    /** forme d'onde pour la transmission analogique ("RZ", "NRZ", "NRZT") */
    private String formeOnde = "RZ";

    /** nombre d'échantillons par bit */
    private int nbEch = 30;

    /** amplitude minimale du signal */
    private float amplMin = 0.0f;

    /** amplitude maximale du signal */
    private float amplMax = 1.0f;

    // --- Paramètres de canal bruité (TP3) ---

    /** indique si la transmission analogique est bruitée (option -snrpb ou -snr 
     * (-snr est en alias car il est invoqué au début du chapitre options de la commande unique)) */
    private boolean canalBruite = false;

    /** valeur du rapport signal sur bruit par bit (Eb/N0 en dB) */
    private Float snrpb = null;

    // --- Paramètres de canal à trajets indirects (-ti) (TP4) ---

    /** indique si le canal analogique comporte des trajets indirects (option -ti) */
    private boolean trajetsMultiples = false;

    /** nombre de trajets indirects (5 au maximum), en plus du trajet direct implicite */
    private int nbTrajets = 0;

    /** décalages temporels de chaque trajet indirect, en nombre d'échantillons, taille nbTrajets */
    private int[] decalagesTrajets = new int[0];

    /** amplitudes relatives de chaque trajet indirect par rapport au trajet direct, taille nbTrajets */
    private float[] amplitudesTrajets = new float[0];

    // --- Diagramme de l'oeil ---

    /** indique si le diagramme de l'oeil doit être affiché (option -oeil) */
    private boolean diagrammeOeil = false;

    // --- Sondage de canal et égalisation (petit plus pour récupérer le signal d'origine) ---

    /** indique si le sondage de canal (en-tête + égaliseur) est actif (option -sondage) */
    private boolean sondage = false;

    /** le composant d'insertion de l'en-tête de sondage, en émission */
    private InsertionEntete inserteurEntete = null;

    /** le composant Récepteur adapté (sondage + égalisation), utilisé à la place de recepteur si -sondage */
    private RecepteurSonde recepteurSonde = null;

    // --- Codage de canal (TP5) ---

    /** indique si le codage de canal est actif (option -codeur) */
    private boolean codeurActif = false;

    /** le composant Codeur de canal (en émission) */
    private CodeurCanal codeur = null;

    /** le composant Décodeur de canal (en réception) */
    private DecodeurCanal decodeur = null;

    // --- Composants de la chaîne ---

    /** le composant Source de la chaîne de transmission */
    private Source<Boolean> source = null;

    /** le composant Transmetteur parfait logique de la chaîne de transmission (TP1) */
    private Transmetteur<Boolean, Boolean> transmetteurLogique = null;

    /** le composant Émetteur (TP2) */
    private Emetteur emetteur = null;

    /** le composant Transmetteur analogique parfait (TP2) */
    private Transmetteur<Float, Float> transmetteurAnalogique = null;

    /** le composant Récepteur (TP2) */
    private Recepteur recepteur = null;

    /** le composant Destination de la chaîne de transmission */
    private Destination<Boolean> destination = null;

    /**
     * Le constructeur de Simulateur construit une chaîne de transmission
     * composée d'une Source, d'une Destination et de Transmetteurs.
     *
     * @param args le tableau des différents arguments.
     * @throws ArgumentsException si un des arguments est incorrect
     */
    public Simulateur(String[] args) throws ArgumentsException {
        // analyser et récupérer les arguments
        analyseArguments(args);

        // Instanciation de la source
        if (messageAleatoire) {
            if (aleatoireAvecGerme) {
                source = new SourceAleatoire(nbBitsMess, seed);
            } else {
                source = new SourceAleatoire(nbBitsMess);
            }
        } else {
            source = new SourceFixe(messageString);
        }

        // Instanciation de la destination commune
        destination = new DestinationFinale();

        // Instanciation du codeur et du décodeur si demandé (-codeur)
        if (codeurActif) {
            codeur = new CodeurCanal();
            decodeur = new DecodeurCanal();
        }

        final int nbPixels = 30;

        if (transmissionAnalogique) {
            // --- Chaîne analogique ---
            emetteur = new Emetteur(formeOnde, nbEch, amplMin, amplMax);
            if (trajetsMultiples) {
                // snrpb reste null (transmission non bruitee) si -snrpb/-snr n'a pas ete fourni
                Float snrpbEffectif = canalBruite ? snrpb : null;
                transmetteurAnalogique = new TransmetteurAnalogiqueTrajetsMultiples(
                    snrpbEffectif, nbEch, nbTrajets, decalagesTrajets, amplitudesTrajets, seed);
            } else if (canalBruite) {
                transmetteurAnalogique = new TransmetteurAnalogiqueBruite(snrpb, nbEch, seed);
            } else {
                transmetteurAnalogique = new TransmetteurParfait<Float>();
            }

            // Connexion des sondes si demandé (-s)
            if (affichage) {
                source.connecter(new SondeLogique("Source", nbPixels));
                if (codeurActif) {
                    codeur.connecter(new SondeLogique("Codeur", nbPixels));
                }
                emetteur.connecter(new SondeAnalogique("Emetteur"));
                transmetteurAnalogique.connecter(new SondeAnalogique("Transmetteur"));
            }

            // Connexion de la sonde diagramme de l'oeil (-oeil), indépendante de -s :
            // observe le signal en sortie du canal, juste avant démodulation.
            if (diagrammeOeil) {
                transmetteurAnalogique.connecter(new SondeOeil("Diagramme de l'oeil", nbEch));
            }

            if (sondage) {
                // --- Chaîne avec sondage de canal + égalisation ---
                // Source -> [Codeur] -> InsertionEntete -> Emetteur -> canal -> RecepteurSonde -> [Decodeur] -> Destination.
                // L'en-tête est ajoutée/retirée en interne : le TEB (calculé sur
                // source.getInformationEmise() / destination.getInformationRecue())
                // ne porte donc que sur le message utile, comme sans -sondage.
                inserteurEntete = new InsertionEntete();
                recepteurSonde = new RecepteurSonde(formeOnde, nbEch, amplMin, amplMax);

                if (diagrammeOeil) {
                    recepteurSonde.setSondeOeilApresEgalisation(
                        new SondeOeil("Diagramme de l'oeil après égalisation", nbEch));
                }

                if (affichage) {
                    recepteurSonde.connecter(new SondeLogique("Recepteur", nbPixels));
                    if (codeurActif) {
                        decodeur.connecter(new SondeLogique("Decodeur", nbPixels));
                    }
                }

                if (codeurActif) {
                    source.connecter(codeur);
                    codeur.connecter(inserteurEntete);
                } else {
                    source.connecter(inserteurEntete);
                }
                inserteurEntete.connecter(emetteur);
                emetteur.connecter(transmetteurAnalogique);
                transmetteurAnalogique.connecter(recepteurSonde);

                if (codeurActif) {
                    recepteurSonde.connecter(decodeur);
                    decodeur.connecter(destination);
                } else {
                    recepteurSonde.connecter(destination);
                }
            } else {
                // --- Chaîne analogique standard (-ti sans sondage) ---
                recepteur = new Recepteur(formeOnde, nbEch, amplMin, amplMax);
                recepteur.setRetardMax(retardMaxCanal());

                if (affichage) {
                    recepteur.connecter(new SondeLogique("Recepteur", nbPixels));
                    if (codeurActif) {
                        decodeur.connecter(new SondeLogique("Decodeur", nbPixels));
                    }
                }

                if (codeurActif) {
                    source.connecter(codeur);
                    codeur.connecter(emetteur);
                } else {
                    source.connecter(emetteur);
                }
                emetteur.connecter(transmetteurAnalogique);
                transmetteurAnalogique.connecter(recepteur);

                if (codeurActif) {
                    recepteur.connecter(decodeur);
                    decodeur.connecter(destination);
                } else {
                    recepteur.connecter(destination);
                }
            }

        } else {
            // --- Chaîne logique (TP1) ---
            transmetteurLogique = new TransmetteurParfait<Boolean>();

            // Connexion des sondes logiques si demandé (-s)
            if (affichage) {
                source.connecter(new SondeLogique("Source", nbPixels));
                if (codeurActif) {
                    codeur.connecter(new SondeLogique("Codeur", nbPixels));
                }
                transmetteurLogique.connecter(new SondeLogique("Transmetteur", nbPixels));
                if (codeurActif) {
                    decodeur.connecter(new SondeLogique("Decodeur", nbPixels));
                }
            }

            // Connexion de la chaîne logique
            if (codeurActif) {
                source.connecter(codeur);
                codeur.connecter(transmetteurLogique);
                transmetteurLogique.connecter(decodeur);
                decodeur.connecter(destination);
            } else {
                source.connecter(transmetteurLogique);
                transmetteurLogique.connecter(destination);
            }
        }
    }

    /**
     * Renvoie le plus grand décalage (en échantillons) des trajets indirects,
     * c'est-à-dire la longueur de la queue ajoutée par le canal. Vaut 0 sans -ti.
     */
    private int retardMaxCanal() {
        int max = 0;
        for (int d : decalagesTrajets) {
            if (d > max) {
                max = d;
            }
        }
        return max;
    }

    /**
     * Extrait d'un tableau de chaînes de caractères les différentes options de la simulation.
     *
     * @param args le tableau des différents arguments.
     * @throws ArgumentsException si un des arguments est incorrect.
     */
    private void analyseArguments(String[] args) throws ArgumentsException {
        for (int i = 0; i < args.length; i++) {

            if (args[i].matches("-s")) {
                affichage = true;
            } else if (args[i].matches("-seed")) {
                aleatoireAvecGerme = true;
                i++;
                if (i >= args.length) {
                    throw new ArgumentsException("Valeur manquante pour le parametre -seed");
                }
                try {
                    seed = Integer.valueOf(args[i]);
                } catch (Exception e) {
                    throw new ArgumentsException("Valeur du parametre -seed invalide :" + args[i]);
                }
            } else if (args[i].matches("-mess")) {
                i++;
                if (i >= args.length) {
                    throw new ArgumentsException("Valeur manquante pour le parametre -mess");
                }
                messageString = args[i];
                if (args[i].matches("[0,1]{7,}")) {
                    messageAleatoire = false;
                    nbBitsMess = args[i].length();
                } else if (args[i].matches("[0-9]{1,6}")) {
                    messageAleatoire = true;
                    nbBitsMess = Integer.valueOf(args[i]);
                    if (nbBitsMess < 1) {
                        throw new ArgumentsException("Valeur du parametre -mess invalide : " + nbBitsMess);
                    }
                } else {
                    throw new ArgumentsException("Valeur du parametre -mess invalide : " + args[i]);
                }
            } else if (args[i].matches("-form")) {
                transmissionAnalogique = true;
                i++;
                if (i >= args.length) {
                    throw new ArgumentsException("Valeur manquante pour le parametre -form");
                }
                String f = args[i].toUpperCase();
                if (f.equals("NRZ") || f.equals("NRZT") || f.equals("RZ")) {
                    formeOnde = f;
                } else {
                    throw new ArgumentsException("Valeur du parametre -form invalide : " + args[i]);
                }
            } else if (args[i].matches("-nbEch")) {
                transmissionAnalogique = true;
                i++;
                if (i >= args.length) {
                    throw new ArgumentsException("Valeur manquante pour le parametre -nbEch");
                }
                try {
                    nbEch = Integer.parseInt(args[i]);
                    if (nbEch <= 0) {
                        throw new ArgumentsException("Valeur du parametre -nbEch invalide : " + args[i]);
                    }
                } catch (NumberFormatException e) {
                    throw new ArgumentsException("Valeur du parametre -nbEch invalide : " + args[i]);
                }
            } else if (args[i].matches("-ampl")) {
                transmissionAnalogique = true;
                if (i + 2 >= args.length) {
                    throw new ArgumentsException("Parametres manquants pour l'option -ampl (attendu : min max)");
                }
                i++;
                try {
                    amplMin = Float.parseFloat(args[i]);
                } catch (NumberFormatException e) {
                    throw new ArgumentsException("Valeur min du parametre -ampl invalide : " + args[i]);
                }
                i++;
                try {
                    amplMax = Float.parseFloat(args[i]);
                } catch (NumberFormatException e) {
                    throw new ArgumentsException("Valeur max du parametre -ampl invalide : " + args[i]);
                }
                if (amplMin >= amplMax) {
                    throw new ArgumentsException("Valeurs du parametre -ampl invalides : min doit etre strictement inferieur a max (" + amplMin + " >= " + amplMax + ")");
                }
            } else if (args[i].matches("-snrpb") || args[i].matches("-snr")) {
                transmissionAnalogique = true;
                canalBruite = true;
                String opt = args[i];
                i++;
                if (i >= args.length) {
                    throw new ArgumentsException("Valeur manquante pour le parametre " + opt);
                }
                try {
                    snrpb = Float.parseFloat(args[i]);
                } catch (NumberFormatException e) {
                    throw new ArgumentsException("Valeur du parametre " + opt + " invalide : " + args[i]);
                }
            } else if (args[i].matches("-ti")) {
                transmissionAnalogique = true;
                trajetsMultiples = true;
                java.util.List<Integer> decalagesList = new java.util.ArrayList<Integer>();
                java.util.List<Float> amplitudesList = new java.util.ArrayList<Float>();
                // On consomme des couples (dt, ar) tant que le token suivant n'est
                // pas l'une des options connues de la commande unique (permet des
                // valeurs negatives pour dt/ar sans les confondre avec une option).
                while (i + 1 < args.length && !OPTIONS_CONNUES.contains(args[i + 1])) {
                    if (decalagesList.size() >= 5) {
                        throw new ArgumentsException("Au maximum 5 trajets indirects sont autorises pour -ti");
                    }
                    int dt;
                    try {
                        dt = Integer.parseInt(args[i + 1]);
                    } catch (NumberFormatException e) {
                        throw new ArgumentsException("Valeur dt du parametre -ti invalide : " + args[i + 1]);
                    }
                    if (dt < 0) {
                        throw new ArgumentsException("Valeur dt du parametre -ti invalide (doit etre >= 0) : " + args[i + 1]);
                    }
                    if (i + 2 >= args.length || OPTIONS_CONNUES.contains(args[i + 2])) {
                        throw new ArgumentsException("Parametre ar manquant pour un trajet indirect de -ti");
                    }
                    float ar;
                    try {
                        ar = Float.parseFloat(args[i + 2]);
                    } catch (NumberFormatException e) {
                        throw new ArgumentsException("Valeur ar du parametre -ti invalide : " + args[i + 2]);
                    }
                    decalagesList.add(dt);
                    amplitudesList.add(ar);
                    i += 2;
                }
                if (decalagesList.isEmpty()) {
                    throw new ArgumentsException("Au moins un couple (dt ar) est attendu pour -ti");
                }
                nbTrajets = decalagesList.size();
                decalagesTrajets = new int[nbTrajets];
                amplitudesTrajets = new float[nbTrajets];
                for (int k = 0; k < nbTrajets; k++) {
                    decalagesTrajets[k] = decalagesList.get(k);
                    amplitudesTrajets[k] = amplitudesList.get(k);
                }
            } else if (args[i].matches("-oeil")) {
                transmissionAnalogique = true;
                diagrammeOeil = true;
            } else if (args[i].matches("-sondage")) {
                transmissionAnalogique = true;
                sondage = true;
            } else if (args[i].matches("-codeur")) {
                codeurActif = true;
            } else {
                throw new ArgumentsException("Option invalide :" + args[i]);
            }
        }

        // Vérification des contraintes sur les amplitudes (TP2 sujet page 8)
        if (transmissionAnalogique) {
            if ("RZ".equalsIgnoreCase(formeOnde)) {
                // Contraintes RZ : Amax >= 0, Amin = 0, Amin < Amax
                if (amplMin != 0.0f) {
                    throw new ArgumentsException("Pour la forme RZ, l'amplitude min doit valoir 0.0 : " + amplMin);
                }
                if (amplMax < 0.0f) {
                    throw new ArgumentsException("Pour la forme RZ, l'amplitude max doit etre >= 0 : " + amplMax);
                }
            } else {
                // Contraintes NRZ et NRZT : Amax >= 0, Amin <= 0, Amin < Amax
                if (amplMin > 0.0f) {
                    throw new ArgumentsException("Pour la forme " + formeOnde + ", l'amplitude min doit etre <= 0 : " + amplMin);
                }
                if (amplMax < 0.0f) {
                    throw new ArgumentsException("Pour la forme " + formeOnde + ", l'amplitude max doit etre >= 0 : " + amplMax);
                }
            }
        }
    }

    /**
     * Effectue un envoi de message par la source de la chaîne de transmission.
     *
     * @throws Exception si un problème survient lors de l'exécution
     */
    public void execute() throws Exception {
        source.emettre();
    }

    /**
     * Calcule le taux d'erreur binaire (TEB) en comparant les bits émis
     * avec les bits reçus par la destination.
     *
     * @return la valeur du TEB (entre 0.0f et 1.0f).
     */
    public float calculTauxErreurBinaire() {
        Information<Boolean> infoEmise = source.getInformationEmise();
        Information<Boolean> infoRecue = destination.getInformationRecue();

        if (infoEmise == null || infoRecue == null || infoEmise.nbElements() == 0) {
            return 0.0f;
        }

        int nbErreurs = 0;
        int nbElementsEmis = infoEmise.nbElements();
        int nbElementsRecus = infoRecue.nbElements();
        int nbElementsCommuns = Math.min(nbElementsEmis, nbElementsRecus);

        for (int i = 0; i < nbElementsCommuns; i++) {
            if (!infoEmise.iemeElement(i).equals(infoRecue.iemeElement(i))) {
                nbErreurs++;
            }
        }

        nbErreurs += Math.abs(nbElementsEmis - nbElementsRecus);

        return (float) nbErreurs / (float) nbElementsEmis;
    }

    /**
     * Renvoie la source utilisée par le simulateur.
     * @return la source
     */
    public Source<Boolean> getSource() {
        return this.source;
    }

    /**
     * Renvoie la destination utilisée par le simulateur.
     * @return la destination
     */
    public Destination<Boolean> getDestination() {
        return this.destination;
    }

    /**
     * Renvoie l'émetteur de la chaîne analogique.
     * @return l'émetteur (ou null si transmission logique)
     */
    public Emetteur getEmetteur() {
        return this.emetteur;
    }

    /**
     * Renvoie le récepteur de la chaîne analogique standard.
     * @return le récepteur (ou null si transmission logique ou si -sondage est actif, cf. {@link #getRecepteurSonde()})
     */
    public Recepteur getRecepteur() {
        return this.recepteur;
    }

    /**
     * Renvoie le transmetteur analogique parfait.
     * @return le transmetteur analogique (ou null si transmission logique)
     */
    public Transmetteur<Float, Float> getTransmetteurAnalogique() {
        return this.transmetteurAnalogique;
    }

    /**
     * Renvoie le transmetteur logique.
     * @return le transmetteur logique (ou null si transmission analogique)
     */
    public Transmetteur<Boolean, Boolean> getTransmetteurLogique() {
        return this.transmetteurLogique;
    }

    /**
     * Indique si la chaîne est analogique.
     * @return true si analogique, false si logique
     */
    public boolean isTransmissionAnalogique() {
        return this.transmissionAnalogique;
    }

    /**
     * Indique si la chaîne utilise un canal bruité.
     * @return true si le canal est bruité, false sinon
     */
    public boolean isCanalBruite() {
        return this.canalBruite;
    }

    /**
     * Renvoie la valeur de snrpb (Eb/N0 en dB).
     * @return snrpb ou null si non bruité
     */
    public Float getSnrpb() {
        return this.snrpb;
    }

    /**
     * Indique si le canal analogique comporte des trajets multiples.
     * @return true si -ti a été utilisé, false sinon
     */
    public boolean isTrajetsMultiples() {
        return this.trajetsMultiples;
    }

    /**
     * Renvoie le nombre de trajets multiples supplémentaires configurés.
     * @return nbTrajets
     */
    public int getNbTrajets() {
        return this.nbTrajets;
    }

    /**
     * Indique si le diagramme de l'oeil doit être affiché.
     * @return true si -oeil a été utilisé, false sinon
     */
    public boolean isDiagrammeOeil() {
        return this.diagrammeOeil;
    }

    /**
     * Indique si le sondage de canal (en-tête + égalisation) est actif.
     * @return true si -sondage a été utilisé, false sinon
     */
    public boolean isSondage() {
        return this.sondage;
    }

    /**
     * Renvoie le récepteur adapté (sondage + égalisation), utilisé à la
     * place de {@link #getRecepteur()} quand -sondage est actif. Donne
     * notamment accès aux décalages/amplitudes de trajets indirects
     * estimés (utile pour le compte-rendu).
     * @return le récepteur avec sondage, ou null si -sondage n'est pas utilisé
     */
    public RecepteurSonde getRecepteurSonde() {
        return this.recepteurSonde;
    }

    /**
     * Indique si le codage de canal est actif (option -codeur).
     * @return true si -codeur a été spécifié, false sinon
     */
    public boolean isCodeur() {
        return this.codeurActif;
    }

    /**
     * Indique si le codage de canal est actif (alias de {@link #isCodeur()}).
     * @return true si -codeur a été spécifié, false sinon
     */
    public boolean isCodageCanal() {
        return this.codeurActif;
    }

    /**
     * Renvoie le composant codeur de canal.
     * @return le codeur (ou null si -codeur n'est pas actif)
     */
    public CodeurCanal getCodeur() {
        return this.codeur;
    }

    /**
     * Renvoie le composant décodeur de canal.
     * @return le décodeur (ou null si -codeur n'est pas actif)
     */
    public DecodeurCanal getDecodeur() {
        return this.decodeur;
    }

    /**
     * Fonction principale : instancie le Simulateur et affiche le TEB.
     *
     * @param args arguments de simulation.
     */
    public static void main(String[] args) {
        Simulateur simulateur = null;

        try {
            simulateur = new Simulateur(args);
        } catch (Exception e) {
            System.out.println(e);
            System.exit(-1);
        }

        try {
            simulateur.execute();
            String s = "java  Simulateur  ";
            for (int i = 0; i < args.length; i++) {
                s += args[i] + "  ";
            }
            System.out.println(s + "  =>   TEB : " + simulateur.calculTauxErreurBinaire());
        } catch (Exception e) {
            System.out.println(e);
            e.printStackTrace();
            System.exit(-2);
        }
    }
}
