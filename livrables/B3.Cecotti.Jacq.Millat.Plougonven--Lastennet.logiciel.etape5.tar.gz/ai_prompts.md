# Prompts IA utilisés lors de la réalisation de ce projet
Par soucis de transparence, ce document contient la majeure partie des prompts IA que nous avons utilisés lors de la réalisation de ce projet.

La majorité des prompts non concluants (absence de réponse pertinente de l'IA ou prompts mal formulés) n'apparaissent pas dans ce document. 

## Prompts du TP1
### Lors de la configuration de notre environnement de développement
* J'ai un fichier console .vv, comment ouvrir la vm ?
* Comment cloner un repo github pour le mettre sur mon PC via vscode ?
* comment annuler mon dernier commit via l'interface vscode ?

### Lors du développement du logiciel
* Mon collègue a utilisé import information.Information; dans son code SourceFixe.java. je dois faire le code SourceAleatoire.java. Explique moi à quoi sert information.information.
* Explique moi comment gérer/utiliser l'hérédité des classes de mon projet, je suis débutant
* Ecris moi le fichier runTests pour tester l'étape 1 de mon projet
    * Par manque de temps, je n'ai pas eu le temps de créer de vrai tests Java. Les tests via commandes bash ont donc entièrement été générés par IA et vont probablement être supprimés/remplacés dans le futur par un travail plus propre.
* Reprends mon code et ajoute le balisage pour la javadoc et ajoute les commentaires que j'ai oublié
* Refais une passe sur mon code et propose des amélioration pour le code 

## Prompts du TP2
* Quand il y avait un merge conflict dans vsc avant avec GitHub, vsc m'ouvrait une interface pour choisir en quelques clics quels lignes garder. Maintenant ça m'affiche juste une pop up avec une erreur
* Le message est juste qu'il ne peut pas merge car y'a un conflit
    * Gemini m'a aidé à débogger le problème. Après quelques manipulations (redémarrage de VSCode et git reset notamment), le problème à disparu et j'ai pu à nouveau résoudre les merge conflicts, qui seront forcément nombreux au court du projet étant donné que nous développons à 4 en même temps.
* J'ai une erreur Error: Could not find or load main class tests.TestSimulateur
Caused by: java.lang.ClassNotFoundException: tests.TestSimulateur quand j'execute .\runtests
    * Le script runtests n'arrivait pas à ouvrir les fichiers .class des tests car le script compile ne prenait pas en charge. Sur recommandation de l'IA, nous avons amélioré ces deux derniers scripts. L'IA nous a aussi prévenu que genDoc ne prenait pas non plus en charge les tests, ce que nous avons corrigé
* Comment faire une liste à points en latex ?
* Comment ajouter des acronymes en latex ?
* comment faire un saut de paragraphe avec une ligne vide entre les deux paragraphes en latex ?
* J'ai un code java, et des tests java que je lance depuis un script bash. Mais j'aimerait pouvoir aussi lancer les tests depuis l'onglet testing de vscode. Il faut que j'ecrive un fichier de configuration ou que je change quelque chose dans mes tests ?
    * Dans un premier temps, nous avions écris les tests Java de manière à ce qu'ils fonctionnent avec le script ./runTests, sans penser au fait qu'il serait plus facile de vérifier leur coverage avec Emma dans VSCode s'il s'agissait de tests JUnit, comme nous l'avions vu en classe. L'IA Copilot nous a recommandé de créer un projet Maven, ce qui est exagéré au vu de la simplicité avec laquelle nous avons réussi à utiliser JUnit sur VSCode en SIT211. J'ai (Yann) donc fait la requête suivante :
        * J'avais réussi à le faire sur un autre projet, sans maven ou truc compliqué, juste avec un fichier .classpath et .project
            * Copilot m'a donc suggéré de simplement compléter le fichier .classpath (ce que j'ai fait en m'inspirant du fichier .classpath que j'avais modifié en SIT211) et d'adapter les tests à JUnit. Cela a provoqué une erreur sur les fichiers de tests. Ces derniers refusaient d'appartenir au package Tests, mais pouvaient toujours être exécutés via le script `runtests`. Par manque de temps, et puisque nous n'avons constaté aucune regression fonctionelle, nous avons livré l'itération 2 avec ce petit problème.
* En t'inspirant des tests JUnit que j'ai rédigé pour les TP1, 2, 3 et des tests bash que tu as généré pour les TP1 et TP2, écris des tests bash pour le TP3.
    * L'objectif des tests bash (déjà générés par IA pour le TP1) est de compléter les tests java par des tests plus rapides à exécuter et facilitant le test des options choisies lors de l'exécution du script simulateur.
* Agis en tant qu'expert en ingénierie logicielle Java et en télécommunications. Analyse le code source fourni ci-dessous pour vérifier s'il implémente correctement et intégralement les exigences de l'**Étape 2** du projet de simulation de chaîne de transmission (SIT 213, IMT Atlantique).
    * Pour confirmer le code j'ai (Enzo) utilisé Mistral Vibe car je préfère les IA avec des droits aux données plus strictes.
* Voici un rapport en LaTeX. Je veux que tu fasse la liste des fautes d'orthographe et de syntaxe des TP1 et TP2 (uniquement).
    * Gemini a été utile pour corriger les dernières fautes que nous n'avions pas vu. On lui demande de faire la liste des erreurs et non pas de corriger directement, afin de pouvoir vérifier ce qu'il est pertinent de corriger ou non.

## Prompts du TP3
* Pourquoi mes fichiers de test refusent d'apartenir au package test.
    * Comme je m'en doutait, le problème venait du fichier .classpath récemment créé pour tenter de faire fonctionner JUnit et Emma dans nos environnements VSCode. Copilot m'a précisé que le problème venait de la ligne <classpathentry kind="src" path="tests"/> qui implique que Java doit considérer les tests comme la racine des packages, et s'attendait donc à ce que les fichiers directement dedans soient dans le package par défaut (sans package tests). Après vérification, il apparait que dans le TP2-3 de SIT211, des fichiers tests n'étaient pas non plus dans le package test ; j'aurai surement pu trouver la solution moi-même en creusant un peu. Fort de cet apprentissage, j'ai donc aussi mis à jour le script runTests pour qu'il prenne en compte le fait que les classes de test n'apartiennent plus au package test.
* D'un point de vue purement "code", est-il pertinent de faire une classe TransmetteurBruite.java et une autre TransmetteurAnalogiqueBruite.java, ou une seule classe TransmetteurAnalogiqueBruite.java ?
    * Dans un premier temps, nous avons développé ces deux classes de manières séparées, puis nous nous sommes rendus-compte qu'une seule classe peut suffir. Copilot a confirmé notre supposition, donc nous avons supprimé la classe TransmetteurBruite.java et adapté le code pour qu'il ne fonctionne qu'avec TransmetteurAnalogiqueBruite.java.
* Génère un script python pour tracer les courbes de TEB pour NRZ, NRZT et RZ à partir de ce fichier excel.
    * Nous avons généré des courbes pour vérifier que les TEB de notre chaine de transmission sont cohérents.
* En t'inspirant des tests JUnit que j'ai rédigé pour les TP1, 2, 3 et des tests bash que tu as généré pour les TP1 et TP2, écris des tests bash pour le TP3.
    * L'objectif des tests bash (déjà générés par IA pour le TP1) est de compléter les tests java par des tests plus rapides à exécuter et facilitant le test des options choisies lors de l'exécution du script simulateur.
* Lis toute la javadoc que nous avons rédigé et dis moi où il y a des erreurs. Fais des recommandations pour améliorer sa lisibilité.
    * Gemini ne nous a pas fait beaucoup de recommandations très importantes donc nous avons peu modifié la javadoc en conséquence. Néanmoins, nous avons suivi certains de ses conseils en harmonisant notre javadoc en ne mettant qu'un auteur par ligne "@author", ainsi qu'en corrigeant des erreurs de syntaxes et de mise en forme.
* Fais la liste des erreurs que tu trouve dans ce rapport.
    * Gemini nous a aidé à corriger les fautes d'orthographe et de syntaxe de notre rapport.

## Prompts du TP4
* Fais la liste des erreurs que tu trouve dans ce rapport.
    * Gemini nous a aidé à corriger les fautes d'orthographe et de syntaxe de notre rapport.
* Agis en tant qu'expert en ingénierie logicielle Java et en télécommunications. Analyse le code source fourni ci-dessous pour vérifier s'il implémente correctement et intégralement les exigences de l'étape 4 du projet.
    * L'IA nous a suggéré quelques fonctionalités manquantes que nous avons développées
* Donne moi les commandes de cette feuille
    * Plutôt que de recopier les commandes de test à la main, nous avons demandé à Gemini de faire le l'OCR sur la feuille de test que l'enseignant de programmation nous a recommandé de prendre en photo.
* Comment revenir en arrière dans la branche git sur vscode ? Je voudrais comparer les performances actuelles et passées du code
    * Cela a été utile pour tester et comparer l'efficacité des corrections que nous avons fait dans le code.

## Prompts du TP5
* Agis en tant qu'expert en ingénierie logicielle Java et en télécommunications. Analyse le code source fourni ci-dessous pour vérifier s'il implémente correctement et intégralement les exigences de l'étape 5 du projet.
    * L'IA nous a suggéré quelques fonctionalités manquantes que nous avons développées
* Génère un script python pour représenter les courbes de TEB.
* Vérifie l'efficacité de notre chaine de transmission avec tes propres tests et la cohérence des résultats obtenus (ils doivent en théorie être meilleurs que ceux sans codage canal)
    * L'IA nous a confirmé que nos résultats étaient bons et cohérents, ce qui a augmenté notre confiance dans les tests qu'on a développés, même si les tests de l'IA ne nous ont pas toujours semblés pertinents. L'objectif de cette requête était de voir si nous avons oublié de vérifier certains résultats.
* Vérifie que nos tests vérifient suffisement bien notre code
    * L'IA nous a suggéré quelques tests supplémentaires que nous avons implémentés, mais surtout beaucoup de tests peu utiles qui visaient juste à monter artificiellement le coverage des tests sans que cela soit forcément pertinent. Nous avons donc peu suivi cette recommandation de l'IA.
* Valide la cohérence et les calculs des résultats théoriques que nous avons calculé dans ce chapitre : [copié/collé d'un extrait de notre rapport]
    * Gemini a validé nos calculs et la cohérence de nos résultats. Il a suggéré quelques améliorations sur la notation utilisée.
* Vérifie les fautes d'orthographe et de syntaxe dans nos commentaires et dans la javadoc. Fais la liste de tes suggestions de modification
    * Je préfère que l'IA fasse une liste de suggestion plutôt que de nous fournir des commentaires déjà corrigés, afin de pouvoir sélectionner moi même les modifications pertinentes.